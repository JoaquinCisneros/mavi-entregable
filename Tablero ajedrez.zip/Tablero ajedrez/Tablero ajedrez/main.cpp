
#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>

using namespace sf;

int main() {
    RenderWindow window(VideoMode(800, 800, 32), "Tablero de Ajedrez");
    Texture whiteTexture;
    Texture blackTexture;
    whiteTexture.loadFromFile("chessw.png");
    blackTexture.loadFromFile("chessb.png");
    int squareSize = 100;
    window.clear();
    for (int i = 0; i < 8; i++) {
        for (int j = 0; j < 8; j++) {
            Sprite squareSprite;
            squareSprite.setPosition(i * squareSize, j * squareSize);

            if ((i + j) % 2 == 0) {
                squareSprite.setTexture(whiteTexture);
            }
            else {
                squareSprite.setTexture(blackTexture);
            }

            window.draw(squareSprite);
        }
    }

    window.display();

    while (window.isOpen()) {
        Event event;
        while (window.pollEvent(event)) {
            if (event.type == Event::Closed) {
                window.close();
            }
        }
    }

    return 0;
}
