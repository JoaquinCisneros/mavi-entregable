#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
using namespace sf;

int main() {
    RenderWindow ventana(VideoMode(800, 600, 32), "Ventana fea");

    Texture cuad_rojo_text;
    Texture cuad_azul_text;
    Texture cuad_amarillo_text;
    Texture cuad_negro_text;
    cuad_rojo_text.loadFromFile("cuad_red.png");
    cuad_azul_text.loadFromFile("cuad_blue.png");
    cuad_amarillo_text.loadFromFile("cuad_yellow.png");
    cuad_negro_text.loadFromFile("chessb.png");


    Sprite cuad_rojo;
    Sprite cuad_azul;
    Sprite cuad_amarillo;
    Sprite cuad_negro;

    cuad_rojo.setTexture(cuad_rojo_text);
    cuad_azul.setTexture(cuad_azul_text);
    cuad_amarillo.setTexture(cuad_amarillo_text);
    cuad_negro.setTexture(cuad_negro_text);

    float refX = (float)cuad_negro_text.getSize().x;
    float refY = (float)cuad_negro_text.getSize().y;

    cuad_rojo.setScale(refX / (float)cuad_rojo_text.getSize().x, refY / (float)cuad_rojo_text.getSize().y);
    cuad_azul.setScale(refX / (float)cuad_azul_text.getSize().x, refY / (float)cuad_azul_text.getSize().y);
    cuad_amarillo.setScale(refX / (float)cuad_amarillo_text.getSize().x, refY / (float)cuad_amarillo_text.getSize().y);
    cuad_negro.setScale(1.0f, 1.0f);

    cuad_amarillo.setPosition(0, 0);
    cuad_rojo.setPosition(refX, 0);
    cuad_azul.setPosition(0, refY);
    cuad_negro.setPosition(refX, refY);

    while (ventana.isOpen()) {
        Event event;
        while (ventana.pollEvent(event)) {
            if (event.type == Event::Closed) {
                ventana.close();
            }
        }

        ventana.clear();
        ventana.draw(cuad_amarillo);
        ventana.draw(cuad_rojo);
        ventana.draw(cuad_azul);
        ventana.draw(cuad_negro);
        ventana.display();
    }

    return 0;
}
