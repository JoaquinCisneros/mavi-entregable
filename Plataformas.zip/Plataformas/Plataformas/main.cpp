#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
using namespace sf;

int main() {
    RenderWindow window(VideoMode(800, 600, 32), "Plataformas");

    Texture platformTexture;
    platformTexture.loadFromFile("cuad_grey.png"); // Carga la textura 

    RectangleShape platforms[7]; // Arreglo de 7 plataformas

    int platformWidth = 40;
    int platformHeight = 80;

    // Configura las 7 plataformas con alturas crecientes y espacio entre ellas
    for (int i = 0; i < 7; i++) {
        platforms[i].setSize(Vector2f(platformWidth, platformHeight));
        platforms[i].setPosition(50.0f + i * 100.0f, 600.0f - platformHeight); // La altura se mide desde el suelo
        platforms[i].setTexture(&platformTexture);
        platformHeight += 40; // Aumenta la altura para la siguiente plataforma
    }

    while (window.isOpen()) {
        Event event;
        while (window.pollEvent(event)) {
            if (event.type == Event::Closed) {
                window.close();
            }
        }

        window.clear();

        // Dibuja las 7 plataformas
        for (int i = 0; i < 7; i++) {
            window.draw(platforms[i]);
        }

        window.display();
    }

    return 0;
}
