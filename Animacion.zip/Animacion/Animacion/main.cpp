#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
using namespace sf;

int main() {
    RenderWindow ventana(VideoMode(800, 600, 32), "Animacion");

    Texture textura;
    textura.loadFromFile("cuad_red.png");

    Sprite sprite;
    sprite.setTexture(textura);
    sprite.setRotation(45);
    sprite.setPosition(350, 300);

    while (ventana.isOpen()) {
        sprite.rotate(0.01f);
        Event event;
        while (ventana.pollEvent(event)) {
            if (event.type == Event::Closed) {
                ventana.close();
            }
        }

        ventana.clear();
        ventana.draw(sprite);
        ventana.display();
    }

    return 0;
}
