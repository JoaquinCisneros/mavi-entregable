//////Bibliotecas//////
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
using namespace sf;
//////Variables//////
Texture texture_a;
Texture texture_b;
Texture texture_c;
Texture texture_d;
Sprite sprite_a;
Sprite sprite_b;
Sprite sprite_c;
Sprite sprite_d;
///Punto de entrada a la aplicaci�n///
int main() {
	//Cargamos la textura del archivo
	texture_a.loadFromFile("rcircle.png");
	texture_b.loadFromFile("rcircle.png");
	texture_c.loadFromFile("rcircle.png");
	texture_d.loadFromFile("rcircle.png");
	//Cargamos el material del sprite
	sprite_a.setTexture(texture_a);
	sprite_b.setTexture(texture_b);
	sprite_c.setTexture(texture_c);
	sprite_d.setTexture(texture_d);
	//Movemos el Sprite
	sprite_b.setPosition(675, 0);
	sprite_c.setPosition(0, 475);
	sprite_d.setPosition(675, 475);
	//Creamos la ventana
	sf::RenderWindow App(sf::VideoMode(800, 600, 32),
		"Puntos rojos");
	// Loop principal
	while (App.isOpen())
	{
		// Limpiamos la ventana
		App.clear();
		// Dibujamos la escena
		App.draw(sprite_a);
		App.draw(sprite_b);
		App.draw(sprite_c);
		App.draw(sprite_d);
		// Mostramos la ventana
		App.display();
	}
	return 0;
}
