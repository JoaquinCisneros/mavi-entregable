#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>

using namespace sf;

Texture fondo_texture;
Sprite fondo_sprite;
float alto;
float ancho;
float escalaX;
float escalaY;

int main() {
    RenderWindow window(VideoMode(800, 600, 32), "Fondo");
    fondo_texture.loadFromFile("fondo.jpg");
    fondo_sprite.setTexture(fondo_texture);
    alto = (float)fondo_texture.getSize().y;
    ancho = (float)fondo_texture.getSize().x;
    escalaX = 800 / ancho;
    escalaY = 600 / alto;
    fondo_sprite.setScale(escalaX, escalaY);
    window.clear();
    window.draw(fondo_sprite);
    window.display();

    while (window.isOpen()) {
        Event event;
        while (window.pollEvent(event)) {
            if (event.type == Event::Closed) {
                window.close();
            }
        }
    }

    return 0;
}
